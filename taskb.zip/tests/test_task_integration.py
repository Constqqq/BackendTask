import pytest
from fastapi.testclient import TestClient
from main import app
from database.db import get_db
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database.models import Base

SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base.metadata.create_all(bind=engine)

def override_get_db():
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

client = TestClient(app)

def test_create_task_integration():
    # Предполагается, что есть эндпоинт /tasks и авторизация отключена или есть тестовый токен
    data = {"title": "Integration Task", "description": "desc", "status": "pending"}
    # Для теста требуется токен, если auth включён. Здесь пример без авторизации.
    response = client.post("/tasks", json=data)
    assert response.status_code in (200, 201, 401, 403)  # зависит от auth
    if response.status_code == 200:
        result = response.json()
        assert result["title"] == "Integration Task"
        assert result["description"] == "desc"
        assert result["status"] == "pending"
