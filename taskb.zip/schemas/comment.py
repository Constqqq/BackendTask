from pydantic import BaseModel

class CommentCreate(BaseModel):
    content: str

class CommentOut(BaseModel):
    id: int
    content: str
    task_id: int
    created_at: str
    updated_at: str | None = None

    class Config:
        orm_mode = True
